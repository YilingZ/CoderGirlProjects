public class ZigZagStitch extends Stitch{

    public void sew () {

        System.out.print("Z");

    }

}
