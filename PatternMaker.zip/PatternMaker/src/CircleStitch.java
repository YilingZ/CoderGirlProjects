public class CircleStitch extends Stitch{

    public void sew () {

        System.out.print("o");

    }

}
