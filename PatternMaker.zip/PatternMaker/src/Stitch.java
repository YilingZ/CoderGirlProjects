public class Stitch {


    public void sew (String stitch) {

        System.out.print(stitch);

    }

}
