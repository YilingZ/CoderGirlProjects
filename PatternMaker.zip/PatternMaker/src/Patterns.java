import java.util.Scanner;

public class Patterns {

    public void printPattern(){

        System.out.println("");

    }

    }

