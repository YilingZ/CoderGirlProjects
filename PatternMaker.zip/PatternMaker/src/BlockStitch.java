public class BlockStitch extends Stitch {

    public void sew () {

        System.out.print("[]");

    }

}
