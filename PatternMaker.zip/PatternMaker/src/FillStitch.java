public class FillStitch extends Stitch {

    public void sew () {

        System.out.print("=");

    }

}
