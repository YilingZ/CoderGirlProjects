public class SmallCrossStitch extends Stitch {


    public void sew () {

        System.out.print("x");

    }

}
