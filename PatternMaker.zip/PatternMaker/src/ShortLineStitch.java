public class ShortLineStitch extends Stitch{

    public void sew () {

        System.out.print("-");

    }


}
