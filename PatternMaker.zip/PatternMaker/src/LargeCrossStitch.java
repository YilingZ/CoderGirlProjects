public class LargeCrossStitch extends Stitch{

    public void sew () {

        System.out.print("X");

    }

}
